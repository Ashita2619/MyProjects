Name: Ashita Jawali
andrew-id: ajawali

The project i took for the term project is the scafolded bee.
My name of the project is "The Bee Pollination Game". Its a simple bee pollination game where we have three bees one is the main player bee which follows the mouse directions and the other two are just the helper bees which takes into consideration the minimum distance of the pollen and moves in that direction and all these bees collects the pollens try going near the flower which has to be pollinated being the same color of the pollen and the flower. Once the flower gets pollinated it gradually grows till it reaches a maximum size or radius for that matter. There are some extra cool things like obstacles be mindful of the obstacles because you will only have five (5) lives and then the game is over.
You Can go to the File named "BeeProject_Ashita.py" and run it in VS code by pressing ctrl B but before that make sure you have all the images present for it to run in your folder and also should have CMU graphics package. The main Screen has the instructions which has to be followed just press enter to move on to the game interface and if u would like a rocking background music then you can press the play button on the top left corner. Also you can press r to restart the game and p to pause and unpause the game.


